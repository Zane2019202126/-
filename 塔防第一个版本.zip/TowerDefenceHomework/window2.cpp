#include "window2.h"
#include "mybutton.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include "window4.h"

Window2::Window2(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(2000,1500);
    //��ʼ��Ϸ�İ�ť
    MyButton * start_btn = new MyButton(":/startbtn.png");
    start_btn->setParent(this);
    start_btn->move(1500,500);
    Window4 * choose1 = new Window4;
    connect(start_btn,&MyButton::clicked,this,[=](){
        this->close();
        choose1->show();
    });
    //���ز˵��İ�ť
    MyButton * back_btn = new MyButton(":/backbtn.png");
    back_btn->setParent(this);
    back_btn->move(1200,1100);
    connect(back_btn,&MyButton::clicked,this,[=](){
        emit goback();
    });
    //������Ϸ�İ�ť
    MyButton * end_btn = new MyButton(":/endgame.png");
    end_btn->setParent(this);
    end_btn->move(0,0);
    connect(end_btn,&MyButton::clicked,this,&Window1::close);
}

void Window2::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/easy.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
