#include "window4.h"
#include "mybutton.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>

Window4::Window4(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(2000,1500);
}

void Window4::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/level1.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
