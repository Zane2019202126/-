#include "myobject.h"


MyObject::MyObject(QPushButton *parent) ://��������,����Ѫ�������λ��
    QPushButton(parent),
    center_pos(x()+width()/2,y()+height()*3/4),
    attack_range(0)
{
    attack_ablt = true;
    ice = false;
    freeze = false;
}

MyObject::~MyObject(){
}

//������Ѫ��
void MyObject::set_max_blood(int max){
    this->max_blood = max;
    this->current_blood = max;
}

//���õ�ǰѪ��
void MyObject::set_current_blood(int n){
    this->current_blood = n;
}

//��ȡ��ǰѪ��
int MyObject::get_current_blood(){
    return this->current_blood;
}

int MyObject::get_max_blood(){
    return this->max_blood;
}

//���ù�����Χ
void MyObject::set_range(int r){
    attack_range = r;
}

//��ȡ������Χ
int MyObject::get_range(){
    return attack_range;
}

//�����ܵ��˺�
void MyObject::getDamage(int damage,bool ice){
    current_blood-=damage;
    //����ӵ��м�������,�Ҹö���û�б�����
    if(ice&&!freeze){
        qDebug()<<"this object was freezed";
        change_state();
        freezed();
    }
}

void MyObject::change_attack_ablt(){
    attack_ablt = !attack_ablt;
}

bool MyObject::get_attack_ablt(){
    return attack_ablt;
}

void MyObject::set_CD_time(int t){
    CD_time = t;
}

void MyObject::cooldown(){
    QTimer *timer = new QTimer(this);
    timer->setSingleShot(true);
    connect(timer,SIGNAL(timeout()),this,SLOT(change_attack_ablt()));
    timer->start(CD_time);
}

void MyObject::set_bullet_pix(QPixmap p){
    bullet_pix = p;
}

QPixmap MyObject::get_bullet_pix(){
    return bullet_pix;
}

void MyObject::set_pixmap(QPixmap p){
    pixmap = p;
}

void MyObject::set_freezed_pix(QPixmap p){
    freezed_pix = p;
}

void MyObject::draw(QPainter *painter){
    // Ѫ���ĳ���
    // ��������,��ɫ�����ʾ������,�̶���С����
    // ��ɫ�����ʾ��ǰ����,��m_currentHp / m_maxHp�ı仯Ӱ��
    static const int Health_Bar_Width = 20;
    painter->save();
    painter->drawPixmap(get_current_pos(),pixmap);
    //qDebug()<<"the enemy's current position is"<<get_current_pos()<<endl;
    QPoint healthBarPoint = get_current_pos() + QPoint(15, -height() / 6);
    // ����Ѫ��
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRect healthBarBackRect(healthBarPoint, QSize(Health_Bar_Width, 2));
    painter->drawRect(healthBarBackRect);
    painter->setBrush(Qt::green);
    QRect healthBarRect(healthBarPoint, QSize((double)get_current_blood() / get_max_blood() * Health_Bar_Width, 2));
    painter->drawRect(healthBarRect);
    painter->restore();
}

void MyObject::set_speed(double sp){
    move_speed = sp;
    low_move_speed = sp/2.0;
}

double MyObject::get_speed(){
    return move_speed;
}

//�����䶳
void MyObject::freezed(){
    QTimer *timer = new QTimer(this);
    timer->setSingleShot(true);
    connect(timer,SIGNAL(timeout()),this,SLOT(change_state()));
    timer->start(4000);
}

//�ı�״̬������/�䶳��
void MyObject::change_state(){
    QPixmap tmp1 = pixmap;
    pixmap = freezed_pix;
    freezed_pix = tmp1;
    double tmp2 = move_speed;
    move_speed = low_move_speed;
    low_move_speed = tmp2;
    freeze = !freeze;
}

void MyObject::set_ice(){
    ice = true;
}

bool MyObject::get_ice(){
    return ice;
}

void MyObject::set_damage(int d){
    damage = d;
}

int MyObject::get_damage(){
    return damage;
}
