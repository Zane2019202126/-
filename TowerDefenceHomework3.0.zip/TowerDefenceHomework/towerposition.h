#ifndef TOWERPOSITION_H
#define TOWERPOSITION_H
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <QWidget>

namespace Ui {
class Towerposition;
}

class Towerposition : public QWidget
{
    Q_OBJECT
public:
    explicit Towerposition(QWidget *parent = nullptr);
    void build();
    ~Towerposition();
signals:
    void build_mask(int x,int y);
    void build_alcohol(int x,int y);
    void build_vaccine(int x,int y);
public slots:

private slots:
    void on_cancel_clicked();
    void on_mask_clicked();
    void on_alcohol_clicked();
    void on_vaccine_clicked();

private:
    Ui::Towerposition *ui;
};

#endif // TOWERPOSITION_H
