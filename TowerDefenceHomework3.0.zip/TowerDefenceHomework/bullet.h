#ifndef BULLET_H
#define BULLET_H

#include <QObject>
#include <QPoint>
#include <QVector2D>
#include <QPainter>
#include <QDebug>
#include "myobject.h"
#include "virus.h"

class Bullet : public QObject
{
    Q_OBJECT
public:
    explicit Bullet(QObject *parent = nullptr);
    void draw(QPainter*painter);
    void move();
    void set_cast_myobject(MyObject *o);
    MyObject* get_cast_myobject();
    void set_target_myobject(MyObject *o);
    void set_current(QPoint pos);
    void set_pixmap(QPixmap);
    QPoint current_pos();
    QPoint start_pos();
    QPoint target_pos();
    void hitTarget();
    bool get_state();
    void set_speed_damage(int);
    void set_ice();
    bool get_ice();
    void set_damage(int);

private:
    QPoint start_point;//��ʼλ��
    MyObject* cast_myobject;//�������
    MyObject* target_myobject;//Ŀ�����
    QPoint target_point;//Ŀ��λ��
    QPoint current_point;//��ǰλ��
    int _damage;
    int speed_damage;
    int _speed;
    QPixmap _pixmap;
    bool hit_state;
    bool _ice;

signals:

public slots:
};

#endif // BULLET_H
