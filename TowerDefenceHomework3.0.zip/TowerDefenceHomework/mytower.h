#ifndef MYTOWER_H
#define MYTOWER_H

#include <QWidget>
#include "myobject.h"
#include "bullet.h"

namespace Ui {
class Option;
}

class Option : public QWidget
{
    Q_OBJECT
public:
    explicit Option(QWidget *parent = nullptr);
    ~Option();
signals:

public slots:
private slots:

private:
    Ui::Option *ui;
};

class MyTower : public MyObject
{
    Q_OBJECT
public:
    explicit MyTower(MyObject *parent = nullptr);
    ~MyTower();
    Option* getopt(){return &_opt;}
    virtual void up();

signals:
private:
    int _level;          //�������ȼ�(��ʱ�䲻���ˣ�ûŪ��
    Option _opt;
    QPixmap _pixmap;

public slots:
};

class Mask:public MyTower
{
    Q_OBJECT
public:
    explicit Mask(MyTower *parent = nullptr);
    ~Mask();
signals:

public slots:
private:
};
class Alcohol:public MyTower
{
    Q_OBJECT
public:
    explicit Alcohol(MyTower *parent = nullptr);
    ~Alcohol();
signals:

public slots:
private:
};
class Vaccine:public MyTower
{
    Q_OBJECT
public:
    explicit Vaccine(MyTower *parent = nullptr);
    ~Vaccine();
signals:

public slots:
private:
};

#endif // MYTOWER_H
