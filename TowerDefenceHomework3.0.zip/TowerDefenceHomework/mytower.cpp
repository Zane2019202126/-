#include "mytower.h"
#include "ui_option.h"

Option::Option(QWidget *parent):
    QWidget(parent),
    ui(new Ui::Option)
{
    ui->setupUi(this);
    connect(ui->cancel,&QPushButton::clicked,this,&Option::hide);
    //������
    ui->cancel->setCursor(QCursor(Qt::PointingHandCursor));
    ui->upgrade->setCursor(QCursor(Qt::PointingHandCursor));
    ui->sell->setCursor(QCursor(Qt::PointingHandCursor));
}

Option::~Option(){
    delete ui;
}

MyTower::MyTower(MyObject *parent) :
    MyObject(parent)
{
    this->setCursor(QCursor(Qt::PointingHandCursor));
    //connect(this,&Elf::clicked,this,&Elf::set_option);
    connect(this,&MyTower::clicked,&_opt,&Option::show);
    //setWindowFlags(Qt::WindowStaysOnTopHint);
}

MyTower::~MyTower(){
}

void MyTower::up(){}

Mask::Mask(MyTower *parent):
    MyTower(parent)
{
    resize(10,10);
    set_damage(15);
    set_CD_time(500);
    set_range(400);
    set_max_blood(100);
    set_ice();                             //���ֿ��Լ������������ٶ�
    set_pixmap(QPixmap(":/mask1_2.png"));
    set_bullet_pix(QPixmap(":/bubble.png"));
}

Mask::~Mask(){
}

Alcohol::Alcohol(MyTower *parent):
    MyTower(parent)
{
    resize(10,10);
    set_damage(30);
    set_CD_time(1000);
    set_range(400);
    set_max_blood(100);
    set_pixmap(QPixmap(":/alcohol1_2.png"));
    set_bullet_pix(QPixmap(":/bubble.png"));
}

Alcohol::~Alcohol(){
}

Vaccine::Vaccine(MyTower *parent):
    MyTower(parent)
{
    resize(10,10);
    set_damage(50);
    set_CD_time(2000);
    set_range(200);
    set_max_blood(100);
    set_pixmap(QPixmap(":/vaccine1_1.png"));
    set_bullet_pix(QPixmap(":/bubble.png"));
}

Vaccine::~Vaccine(){
}
