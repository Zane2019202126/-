#ifndef OBJECT_H
#define OBJECT_H

#include <QWidget>
#include <QPainter>
#include <QPushButton>
#include <QTimer>
#include <QDebug>

class MyObject : public QPushButton
{
public:
    explicit MyObject(QPushButton *parent = nullptr);
    ~MyObject();
    void    set_max_blood(int max);
    void    set_current_blood(int n);
    int     get_current_blood();
    int     get_max_blood();
    void    _move();
    void    set_range(int);
    int     get_range();
    void    getDamage(int,bool);
    QPoint  get_center_pos(){return center_pos;}
    void    set_center_pos(const QPoint & p){center_pos = p;}
    QPoint  get_current_pos(){return current_pos;}
    void    set_current_pos(QPoint p){current_pos = p;}
    bool    get_attack_ablt();
    void    cooldown();
    void    set_CD_time(int);
    void    set_pixmap(QPixmap);
    void    set_freezed_pix(QPixmap);
    void    set_bullet_pix(QPixmap);
    QPixmap get_bullet_pix();
    void    draw(QPainter*);
    void    set_speed(double );
    double  get_speed();
    void    freezed();
    void    set_ice();
    bool    get_ice();
    void    set_damage(int);
    int     get_damage();

public slots:
    void change_attack_ablt();
    void change_state();

private:
    double move_speed;  //ǰ���ٶ�
    double low_move_speed;//�����ٶ�
    int max_blood;//��Ѫ
    int current_blood;//��ǰѪ��
    bool attack_ablt;//�ܷ񹥻�
    int damage;     //����˺�
    int attack_range;//������Χ
    int CD_time;    //������ȴʱ��
    bool ice;//�Ƿ��б�����
    bool freeze;//�Ƿ񱻱���
    QPoint current_pos;//��ǰλ��
    QPoint center_pos; //��ǰ���ĵ�����
    QPixmap pixmap;//����ͼƬ
    QPixmap freezed_pix;//����ͼƬ
    QPixmap bullet_pix;//�ӵ�ͼƬ
};

#endif // OBJECT_H
