#ifndef WINDOW4_H
#define WINDOW4_H

#include <QMainWindow>
#include "window2.h"
#include "window3.h"
#include "mytower.h"
#include <QList>
#include "towerposition.h"
#include <QWidget>
#include <QPushButton>
#include <QPainter>
#include <QTimer>
#include "virus.h"

namespace Ui {
class Window4_1;
class Result;
}

class Window4 : public QMainWindow
{
    Q_OBJECT
public:
    friend class Window4_1;
    friend class Bullet;
    explicit Window4(QWidget *parent = 0);
    ~Window4();
    void set_tower();
    void paintEvent(QPaintEvent *);
    void set_round_total(int);
    void addWayPoints();
    void game_result();
    void deal_damage();
    void removedVirus(Virus1* virus);
    void removedBullet(Bullet* bullet);
    bool loadWave(int*);
    void set_window4(QPixmap p){window4 = p;}
    void attack(MyObject *attacker,MyObject *target);

private slots:
    void updateWindow4();
    void build_mask(int,int);
    void build_alcohol(int,int);
    void build_vaccine(int,int);

signals:
private:
    int life = 5;       //����
    int money;      //�����
    int round_total;//������
    int round_now = 0;  //Ŀǰ����
    QList<Virus1*> virus_list;
    QList<WayPoint*> waypoint_list;
    QList<MyTower*> mytower_list;
    QList<Towerposition*> towerposition_list;
    QList<Bullet*> bullet_list;
    QPixmap window4;
    bool game_win;
public slots:
};

class Result : public QWidget
{
    Q_OBJECT
public:
    explicit Result(QWidget *parent = nullptr);
    ~Result();
private:
    Ui::Result *ui;
};

class Window4_1 : public Window4
{
    Q_OBJECT
public:
    explicit Window4_1(Window4 *parent = nullptr);
    ~Window4_1();
    void addtowerpositions();
    void addWayPoints();
private slots:
    //void on_backsub_clicked();
    void on_btn1_clicked();
    void on_startbtn_clicked();
    void updateWindow4_1();
signals:
    void Backsub();
private:
    Ui::Window4_1 *ui;
};

#endif // WINDOW4_H
