#include "bullet.h"

Bullet::Bullet(QObject *parent):
    QObject(parent)
{
    _speed = 15;
    _damage = 30;
    speed_damage = 0;
    hit_state = false;
    _ice = false;
}

//�����ӵ�
void Bullet::draw(QPainter*painter){
    painter->save();
    painter->drawPixmap(current_point,_pixmap);
    painter->restore();
}

//�ӵ��ƶ�
void Bullet::move(){
    //qDebug()<<"the target point is "<<"("<<target_point.x()<<","<<target_point.y()<<")";
    if(collision(current_point,10,target_point,10)){
        hitTarget();
        hit_state = true;
        return;
    }
    target_point = target_myobject->get_current_pos();
    QVector2D normalized(target_point - current_point);
    normalized.normalize();
    current_point = current_point + normalized.toPoint() * _speed;
}

//���÷������
void Bullet::set_cast_myobject(MyObject *o){
    cast_myobject = o;
    start_point = cast_myobject->get_current_pos();
}

//��ȡ�������
MyObject* Bullet::get_cast_myobject(){
    return cast_myobject;
}

//����Ŀ�����
void Bullet::set_target_myobject(MyObject *o){
    target_myobject = o;
}

//�����ӵ���ǰλ��
void Bullet::set_current(QPoint pos){
    current_point = pos;
}

//�����ӵ���ǰλ��
QPoint Bullet::current_pos(){
    return current_point;
}

//�����ӵ���ʼλ��
QPoint Bullet::start_pos(){
    return start_point;
}

QPoint Bullet::target_pos(){
    return target_point;
}

//�ӵ�����Ŀ��
void Bullet::hitTarget(){
    target_myobject->getDamage(_damage,_ice);
}

bool Bullet::get_state(){
    return hit_state;
}

void Bullet::set_pixmap(QPixmap p){
    _pixmap = p;
}

void Bullet::set_speed_damage(int d){
    speed_damage = d;
}

void Bullet::set_ice(){
    _ice = true;
}

bool Bullet::get_ice(){
    return _ice;
}

void Bullet::set_damage(int d){
    _damage = d;
}
