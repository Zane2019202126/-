#include "towerposition.h"
#include <QPainter>
#include "ui_towerposition.h"

Towerposition::Towerposition(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Towerposition)
{
    ui->setupUi(this);
    this->show();
    ui->mask->hide();
    ui->alcohol->hide();
    ui->vaccine->hide();
    ui->cancel->hide();
    connect(ui->button,&QPushButton::clicked,this,&Towerposition::build);
    //�������ȥ����
    ui->cancel->setCursor(QCursor(Qt::PointingHandCursor));
    ui->mask->setCursor(QCursor(Qt::PointingHandCursor));
    ui->alcohol->setCursor(QCursor(Qt::PointingHandCursor));
    ui->vaccine->setCursor(QCursor(Qt::PointingHandCursor));
    ui->button->setCursor(QCursor(Qt::PointingHandCursor));
}

Towerposition::~Towerposition(){
    delete ui;
}

void Towerposition::build(){
    ui->mask->show();
    ui->alcohol->show();
    ui->vaccine->show();
    ui->cancel->show();
    ui->button->hide();
}

//���һ��ȡ����
void Towerposition::on_cancel_clicked()
{
    ui->mask->hide();
    ui->alcohol->hide();
    ui->vaccine->hide();
    ui->cancel->hide();
    ui->button->show();
}

//������
void Towerposition::on_mask_clicked()
{
    emit build_mask(this->x()+75,this->y()+55);
    ui->mask->hide();
    ui->alcohol->hide();
    ui->vaccine->hide();
    ui->cancel->hide();
}

//�ƾ���
void Towerposition::on_alcohol_clicked()
{
    emit build_alcohol(this->x()+75,this->y()+55);
    ui->mask->hide();
    ui->alcohol->hide();
    ui->vaccine->hide();
    ui->cancel->hide();
}

//������
void Towerposition::on_vaccine_clicked()
{
    emit build_vaccine(this->x()+75,this->y()+55);
    ui->mask->hide();
    ui->alcohol->hide();
    ui->vaccine->hide();
    ui->cancel->hide();
}
