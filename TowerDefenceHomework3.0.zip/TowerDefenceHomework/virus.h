#ifndef VIRUS_H
#define VIRUS_H

#include <QVector2D>
#include <qmath.h>
#include <QPixmap>
#include "myobject.h"
#include <QWidget>
#include <QPoint>
#include <math.h>


class WayPoint
{
public:
    WayPoint(QPoint pos = *new QPoint);
    void setNext(WayPoint *next);
    WayPoint* next()const;
    const QPoint pos()const;
    void operator =(const WayPoint* w);
private:
    QPoint _pos;
    WayPoint * _next;
};

class Virus1 : public MyObject
{
    Q_OBJECT
public:
    explicit Virus1(MyObject *parent = nullptr);
    ~Virus1();
    void setdes(WayPoint *des);
    void march();
    QPoint currentPos();
    void setCurrentPos(QPoint);

signals:
    void damage_base();

public slots:
    void doActiate();

private:
    WayPoint _destination;//Ŀ���
    int _value;  //����������
    bool _active;
};

class Virus2 : public Virus1
{
    Q_OBJECT
public:
    explicit Virus2(Virus1 *parent = nullptr);

signals:

public slots:
};

class Virus3 : public Virus1
{
    Q_OBJECT
public:
    explicit Virus3(Virus1 *parent = nullptr);

signals:

public slots:
};

bool collision(QPoint point1,int r1,QPoint point2,int r2);
int distance(QPoint point1,QPoint point2);

#endif // VIRUS_H
