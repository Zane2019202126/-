#include "window4.h"
#include "mybutton.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include <QTimer>
#include "mytower.h"
#include "ui_window4_1.h"
#include "ui_result.h"
#include "virus.h"


Window4::Window4(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(2000,1500);
    money = 200;//��ʼ���Ϊ200
    round_now=0;//��ǰΪ��0��
    //�����е��˵�damage�źű���������
    for(int i=0;i<virus_list.length();i++)
        connect(virus_list[i],&Virus1::damage_base,this,&Window4::deal_damage);
    QTimer *timer = new QTimer(this);
    connect(timer,&QTimer::timeout,this,&Window4::updateWindow4);
    timer->start(10);
    foreach (MyTower *mytower, mytower_list) {
        mytower->show();
    }

}

Window4::~Window4(){
    qDeleteAll(waypoint_list);
    waypoint_list.clear();
    qDeleteAll(mytower_list);
    mytower_list.clear();
    qDeleteAll(virus_list);
    virus_list.clear();
    qDeleteAll(towerposition_list);
    towerposition_list.clear();
    qDeleteAll(bullet_list);
    bullet_list.clear();
}

void Window4::set_round_total(int n){
    this->round_total = n;
}

//����
void Window4::paintEvent(QPaintEvent *){
//    QPainter painter(this);
//    QPixmap pixmap(":/level1.png");                                       //���ӵ�һ�ر���
//    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    QPixmap Pix = window4.scaled(width(),height());
    QPainter Pixpainter(&Pix);
    //int i=0;
    foreach (Virus1* virus, virus_list) {
        virus->draw(&Pixpainter);
        //i++;
        //qDebug()<<"the "<<i<<" enemy was drawed"<<endl;
        //qDebug()<<"current position is"<<enemy->currentPos()<<endl;
    }
    foreach (Bullet *bullet,bullet_list){
        bullet->draw(&Pixpainter);
        //qDebug()<<"the "<<i<<" bullet was drawed";
        //qDebug()<<"this bullet's current position is"<<bullet->current_pos();
    }
    foreach (MyTower *mytower, mytower_list) {
        mytower->draw(&Pixpainter);
        //qDebug()<<"the "<<i<<" elf was drawed";
        //qDebug()<<"this elf's position is ("<<elf->x()<<","<<elf->y()<<")";
    }
    QPainter painter(this);
    painter.drawPixmap(0,0,Pix);
}

void Window4::updateWindow4()
{
    int i=0;
    foreach (MyTower *mytower, mytower_list) {
        int i = 0;
        foreach (Virus1 *virus, virus_list){
            //������˽��빥����Χ
            i++;
            qDebug()<<i<<" enemy was checked";
            if(distance(mytower->get_current_pos(),virus->get_current_pos())<=mytower->get_range()){
                attack(mytower,virus);
                qDebug()<<i<<" enemy was aimed";
            }
        }
    }
    foreach (Virus1 *virus, virus_list){
        //qDebug()<<"this enemy's blood is"<<enemy->get_current_blood();
        if(virus->get_current_blood()<=0){
            removedVirus(virus);
            continue;
        }
        virus->march();
        //qDebug()<<"the "<<i<<" enemy marched";
        //qDebug()<<"current position is"<<enemy->currentPos();
    }
    foreach (Bullet *bullet,bullet_list){
        i++;
        //qDebug()<<"the "<<i<<" bullet should move";
        bullet->move();
        //qDebug()<<"the "<<i<<" bullet moved";
        //����ӵ��ѻ��У���ȥ
        if(bullet->get_state()){
            removedBullet(bullet);
        }
        //���Ŀ��㳬����̣���ȥ
        if(distance(bullet->target_pos(),bullet->start_pos())>=bullet->get_cast_myobject()->get_range()){
            removedBullet(bullet);
        }
        //����ӵ�������̣���ȥ

        if(distance(bullet->current_pos(),bullet->start_pos())>=bullet->get_cast_myobject()->get_range()){
            removedBullet(bullet);
        }
    }
    update();
}

//����������
void Window4::deal_damage(){
    life--;
    if(life == 0)game_win = false;
}

//�ж���Ϸ���
void Window4::game_result(){
    Result *result;
    result = new Result;
    result->setParent(this);
    result->resize(420,260);
    result->move(400,300);
    if(game_win){
        //��Ϸʤ��������ʤ������
        result->setStyleSheet(tr("image: url(:/win.png);"));
    }else{
        //��Ϸʧ�ܣ�����ʧ�ܽ���
        result->setStyleSheet(tr("image: url(:/fail.png);"));
    }
}

//������������ȥ
void Window4::removedVirus(Virus1* virus){
    Q_ASSERT(virus);
    virus_list.removeOne(virus);
    delete virus;
    if(virus_list.empty()){
        round_now++;
        int e[]={ 100, 500, 600, 1000, 3000, 6000 };
        if(!loadWave(e)){
            game_win = true;
        }
    }
}

//�ӵ����У���ȥ
void Window4::removedBullet(Bullet* bullet){
    Q_ASSERT(bullet);
    bullet_list.removeOne(bullet);
    delete bullet;
}

//��������
void Window4::build_mask(int x,int y){
    Mask* mask;
    mask = new Mask;
    mask->set_current_pos(QPoint(x+10,y+20));
    mask->move(QPoint(x,y));
    mytower_list.push_back(mask);
    mask->setParent(this);
    mask->getopt()->setParent(this);
    mask->getopt()->move(x-90,y-100);
    mask->show();
}

//�����ƾ�
void Window4::build_alcohol(int x,int y){
    Alcohol* alcohol;
    alcohol = new Alcohol;
    alcohol->set_current_pos(QPoint(x+10,y+20));
    alcohol->move(QPoint(x,y));
    mytower_list.push_back(alcohol);
    alcohol->setParent(this);
    alcohol->getopt()->setParent(this);
    alcohol->getopt()->move(x-90,y-100);
    alcohol->show();
}
//��������
void Window4::build_vaccine(int x,int y){
    Vaccine* vaccine;
    vaccine = new Vaccine;
    vaccine->set_current_pos(QPoint(x+5,y+5));
    vaccine->move(QPoint(x-5,y-10));
    mytower_list.push_back(vaccine);
    vaccine->setParent(this);
    vaccine->getopt()->setParent(this);
    vaccine->getopt()->move(x-90,y-100);
    vaccine->show();
}

bool Window4::loadWave(int *virusStartInterval){
    //��󲨽���
    if(round_now>round_total)
        return false;
    //ÿ��6������
    for(int i=0;i<6;i++){
        Virus1 *virus = new Virus1;
        virus->setParent(this);
        //������һ����
        virus->set_current_pos(waypoint_list[0]->pos());
        //���õڶ��е�ΪĿ���
        virus->setdes(waypoint_list[0]);
        virus_list.push_back(virus);
        QTimer::singleShot(virusStartInterval[i], virus, SLOT(doActiate()));
    }
    return true;
}

void Window4::attack(MyObject *attacker,MyObject *target){
    //�������ȴ��
    if(!attacker->get_attack_ablt())return;
    //�����ȴ����
    Bullet *bullet = new Bullet;
    qDebug()<<"one bullet was cast";
    bullet->setParent(this);
    //����������б����ԣ����ӵ��б�����
    if(attacker->get_ice())bullet->set_ice();
    bullet->set_damage(attacker->get_damage());
    bullet->set_cast_myobject(attacker);
    bullet->set_pixmap(attacker->get_bullet_pix());
    bullet->set_current(attacker->get_current_pos());
    bullet->set_target_myobject(target);
    bullet_list.push_back(bullet);
    //��������ȴ
    attacker->change_attack_ablt();
    attacker->cooldown();
}

//�������
Result::Result(QWidget *parent):
    QWidget(parent),
    ui(new Ui::Result)
{
    ui->setupUi(this);
    this->show();
}

Result::~Result(){
    delete ui;
}

//��ͼ1
Window4_1::Window4_1(Window4 *parent) :
    Window4(parent),
    ui(new Ui::Window4_1)
{
    ui->setupUi(this);
    ui->backbtn->setCursor(QCursor(Qt::PointingHandCursor));
    ui->startbtn->setCursor(QCursor(Qt::PointingHandCursor));
    //�����ͼ
    set_window4(QPixmap (":/level1.png"));
    set_round_total(5);//�ܲ���Ϊ5
    QTimer *timer = new QTimer(this);
    connect(timer,&QTimer::timeout,this,&Window4_1::updateWindow4_1);
    timer->start(10);
    addtowerpositions();
    addWayPoints();
}

Window4_1::~Window4_1()
{
    delete ui;
}

//���ӷ�����λ��
void Window4_1::addtowerpositions(){
    Towerposition *b1 = new Towerposition(this);
    b1->move(0,550);
    towerposition_list.push_back(b1);
    Towerposition *b2 = new Towerposition(this);
    b2->move(275,550);
    towerposition_list.push_back(b2);
    Towerposition *b3 = new Towerposition(this);
    b3->move(0,725);
    towerposition_list.push_back(b3);
    Towerposition *b4 = new Towerposition(this);
    b4->move(275,725);
    towerposition_list.push_back(b4);
    Towerposition *b5 = new Towerposition(this);
    b5->move(0,900);
    towerposition_list.push_back(b5);
    Towerposition *b6 = new Towerposition(this);
    b6->move(250,1100);
    towerposition_list.push_back(b6);
    Towerposition *b7 = new Towerposition(this);
    b7->move(425,725);
    towerposition_list.push_back(b7);
    Towerposition *b8 = new Towerposition(this);
    b8->move(600,550);
    towerposition_list.push_back(b8);
    Towerposition *b9 = new Towerposition(this);
    b9->move(775,550);
    towerposition_list.push_back(b9);
    Towerposition *b10 = new Towerposition(this);
    b10->move(950,550);
    towerposition_list.push_back(b10);
    Towerposition *b11 = new Towerposition(this);
    b11->move(1125,550);
    towerposition_list.push_back(b11);
    Towerposition *b12 = new Towerposition(this);
    b12->move(775,900);
    towerposition_list.push_back(b12);
    Towerposition *b13 = new Towerposition(this);
    b13->move(950,900);
    towerposition_list.push_back(b13);
    Towerposition *b14 = new Towerposition(this);
    b14->move(1300,725);
    towerposition_list.push_back(b14);
    Towerposition *b15 = new Towerposition(this);
    b15->move(1450,725);
    towerposition_list.push_back(b15);
    Towerposition *b16 = new Towerposition(this);
    b16->move(1300,1100);
    towerposition_list.push_back(b16);
    Towerposition *b17 = new Towerposition(this);
    b17->move(1450,1100);
    towerposition_list.push_back(b17);
    Towerposition *b18 = new Towerposition(this);
    b18->move(1450,550);
    towerposition_list.push_back(b18);
    Towerposition *b19 = new Towerposition(this);
    b19->move(1450,350);
    towerposition_list.push_back(b19);
    Towerposition *b20 = new Towerposition(this);
    b20->move(1750,900);
    towerposition_list.push_back(b20);
    Towerposition *b21 = new Towerposition(this);
    b21->move(1750,725);
    towerposition_list.push_back(b21);
    Towerposition *b22 = new Towerposition(this);
    b22->move(1750,550);
    towerposition_list.push_back(b22);
    Towerposition *b23 = new Towerposition(this);
    b23->move(1750,350);
    towerposition_list.push_back(b23);
    Towerposition *b24 = new Towerposition(this);
    b24->move(425,1100);
    towerposition_list.push_back(b24);
    for(int i=0;i<24;i++){
        connect(towerposition_list[i],SIGNAL(build_mask(int,int)),this,SLOT(build_mask(int,int)));
        connect(towerposition_list[i],SIGNAL(build_alcohol(int,int)),this,SLOT(build_alcohol(int,int)));
        connect(towerposition_list[i],SIGNAL(build_vaccine(int,int)),this,SLOT(build_vaccine(int,int)));
    }
}

void Window4_1::addWayPoints(){
    WayPoint *waypoint1 = new WayPoint(QPoint(250,400));
    waypoint_list.push_back(waypoint1);

    WayPoint *waypoint2 = new WayPoint(QPoint(250,1000));
    waypoint_list.push_back(waypoint2);
    waypoint1->setNext(waypoint2);

    WayPoint *waypoint3 = new WayPoint(QPoint(700,1000));
    waypoint_list.push_back(waypoint3);
    waypoint2->setNext(waypoint3);

    WayPoint *waypoint4 = new WayPoint(QPoint(700,800));
    waypoint_list.push_back(waypoint4);
    waypoint3->setNext(waypoint4);

    WayPoint *waypoint5 = new WayPoint(QPoint(1200,800));
    waypoint_list.push_back(waypoint5);
    waypoint4->setNext(waypoint5);

    WayPoint *waypoint6 = new WayPoint(QPoint(1200,1000));
    waypoint_list.push_back(waypoint6);
    waypoint5->setNext(waypoint6);

    WayPoint *waypoint7 = new WayPoint(QPoint(1700,1000));
    waypoint_list.push_back(waypoint7);
    waypoint6->setNext(waypoint7);

    WayPoint *waypoint8 = new WayPoint(QPoint(1700,450));
    waypoint_list.push_back(waypoint8);
    waypoint7->setNext(waypoint8);
}

//���عؿ�ѡ��ҳ��
//void Window4_1::on_backsub_clicked()
//{
//    emit Backsub();
//    qDebug()<<"signal was emited";
//}

//���λ��һ
void Window4_1::on_btn1_clicked()
{
    Towerposition *p;
    p = new Towerposition(this);
    p->move(ui->btn1->x()-81,ui->btn1->y()-101);
}

void Window4_1::on_startbtn_clicked()
{
    int e[]={ 100, 1000, 2000, 3000, 4500, 6000 };
    loadWave(e);
    ui->startbtn->hide();
}

void Window4_1::updateWindow4_1()
{
    foreach (MyTower *mytower, mytower_list) {
        int i = 0;
        foreach (Virus1 *virus, virus_list){
            //������˽��빥����Χ
            i++;
            qDebug()<<i<<" enemy was checked";
            if(distance(mytower->get_current_pos(),virus->get_current_pos())<=mytower->get_range()){
                attack(mytower,virus);
                qDebug()<<i<<" enemy was aimed";
            }
        }
    }
    foreach (Virus1 *virus, virus_list){
        //qDebug()<<"this enemy's blood is"<<enemy->get_current_blood();
        if(virus->get_current_blood()<=0){
            removedVirus(virus);
            continue;
        }
        virus->march();
        //qDebug()<<"the "<<i<<" enemy marched";
        //qDebug()<<"current position is"<<enemy->currentPos();
    }
    foreach (Bullet *bullet,bullet_list){
        //i++;
        //qDebug()<<"the "<<i<<" bullet should move";
        bullet->move();
        //qDebug()<<"the "<<i<<" bullet moved";
        //����ӵ��ѻ��У���ȥ
        if(bullet->get_state()){
            removedBullet(bullet);
        }
        //���Ŀ��㳬����̣���ȥ
        if(distance(bullet->target_pos(),bullet->start_pos())>=bullet->get_cast_myobject()->get_range()){
            removedBullet(bullet);
        }
        //����ӵ�������̣���ȥ
        //qDebug()<<"the distance between bullet and cast_object is"<<distance(bullet->current_pos(),bullet->start_pos());
        //qDebug()<<"the bullet's position is "<<bullet->current_pos();
        //qDebug()<<"the bullet's start point is "<<bullet->start_pos();
        if(distance(bullet->current_pos(),bullet->start_pos())>=bullet->get_cast_myobject()->get_range()){
            removedBullet(bullet);
        }
    }
    update();
}
